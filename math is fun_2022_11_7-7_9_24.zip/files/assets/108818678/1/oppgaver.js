var x;
var y;

function lagOppgaver(){
    var x = Math.random()*100;
    var y = Math.random()*100;

    var sum = x+y;

    return sum;

}
var Oppgaver = pc.createScript('oppgaver');

// initialize code called once per entity
Oppgaver.prototype.initialize = function() {
    var sum = lagOppgaver();
    

    

};

// update code called every frame
Oppgaver.prototype.update = function(dt) {
    this.entity.translateLocal(0.01,0,0);

};

// swap method called for script hot-reloading
// inherit your script state here
// Oppgaver.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// https://developer.playcanvas.com/en/user-manual/scripting/